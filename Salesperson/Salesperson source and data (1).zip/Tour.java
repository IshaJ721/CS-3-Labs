public class Tour 
{
	/** create an empty tour */
	public Tour()
	{
		//TODO
	}
	
	/** create a four-point tour, for debugging */
	public Tour(Point a, Point b, Point c, Point d)
	{
		//TODO
	}
	
	/** print tour (one point per line) to std output */
	public void show()
	{
		//TODO
	}
	
	/** draw the tour using StdDraw */
	public void draw()
	{
		//TODO
	}
	
	/** return number of nodes in the tour */
	public int size()
	{
		//TODO
		
		return 0;
	}
	
	/** return the total distance "traveled", from start to all nodes and back to start */
	public double distance()
	{
		//TODO
		
		return 0.0;
	}
	
	/** insert p using nearest neighbor heuristic */
    public void insertNearest(Point p) 
    {
        //TODO
    }

	/** insert p using smallest increase heuristic */
    public void insertSmallest(Point p) 
    {
    	//TODO
    }
}